#pragma once
#include "CoreMinimal.h"
#include "VertexColorFlags.generated.h"

USTRUCT(BlueprintType)
struct ALTAR_API FVertexColorFlags {
    GENERATED_BODY()
public:
    FVertexColorFlags();
};

