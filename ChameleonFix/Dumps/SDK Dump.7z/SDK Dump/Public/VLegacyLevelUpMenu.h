#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyLevelUpMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyLevelUpMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyLevelUpMenu();

};

