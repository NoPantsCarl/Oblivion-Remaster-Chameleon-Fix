#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacySpellMakingMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacySpellMakingMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacySpellMakingMenu();

};

