#pragma once
#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "VPreviewDefaultLocationRotation.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UVPreviewDefaultLocationRotation : public UDataTable {
    GENERATED_BODY()
public:
    UVPreviewDefaultLocationRotation();

};

