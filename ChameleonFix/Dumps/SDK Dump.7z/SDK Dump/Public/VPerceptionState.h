#pragma once
#include "CoreMinimal.h"
#include "VPerceptionState.generated.h"

USTRUCT(BlueprintType)
struct FVPerceptionState {
    GENERATED_BODY()
public:
    ALTAR_API FVPerceptionState();
};

