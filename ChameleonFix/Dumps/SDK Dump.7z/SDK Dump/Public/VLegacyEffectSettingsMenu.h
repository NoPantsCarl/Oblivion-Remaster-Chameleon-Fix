#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyEffectSettingsMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyEffectSettingsMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyEffectSettingsMenu();

};

