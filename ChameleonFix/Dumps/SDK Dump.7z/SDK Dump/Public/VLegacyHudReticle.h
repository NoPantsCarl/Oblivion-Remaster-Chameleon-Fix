#pragma once
#include "CoreMinimal.h"
#include "VAltarWidget.h"
#include "VLegacyHudReticle.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyHudReticle : public UVAltarWidget {
    GENERATED_BODY()
public:
    UVLegacyHudReticle();

};

