#pragma once
#include "CoreMinimal.h"
#include "ESPDataProperty.generated.h"

USTRUCT(BlueprintType)
struct ALTAR_API FESPDataProperty {
    GENERATED_BODY()
public:
    FESPDataProperty();
};

