#pragma once
#include "CoreMinimal.h"
#include "VNavigableHorizontalBox.h"
#include "VAltarNavigableHorizontalBox.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVAltarNavigableHorizontalBox : public UVNavigableHorizontalBox {
    GENERATED_BODY()
public:
    UVAltarNavigableHorizontalBox();

};

