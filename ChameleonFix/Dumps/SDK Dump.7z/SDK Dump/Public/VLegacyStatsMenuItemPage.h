#pragma once
#include "CoreMinimal.h"
#include "VAltarWidget.h"
#include "VLegacyStatsMenuItemPage.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyStatsMenuItemPage : public UVAltarWidget {
    GENERATED_BODY()
public:
    UVLegacyStatsMenuItemPage();

};

