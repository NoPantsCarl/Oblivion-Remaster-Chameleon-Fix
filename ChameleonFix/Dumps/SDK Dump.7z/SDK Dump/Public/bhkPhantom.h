#pragma once
#include "CoreMinimal.h"
#include "bhkWorldObject.h"
#include "bhkPhantom.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UbhkPhantom : public UbhkWorldObject {
    GENERATED_BODY()
public:
    UbhkPhantom();

};

