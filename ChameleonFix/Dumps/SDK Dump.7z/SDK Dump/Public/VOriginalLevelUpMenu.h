#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VOriginalLevelUpMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVOriginalLevelUpMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVOriginalLevelUpMenu();

};

