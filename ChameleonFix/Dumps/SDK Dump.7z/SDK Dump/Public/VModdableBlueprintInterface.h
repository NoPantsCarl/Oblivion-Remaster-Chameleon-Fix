#pragma once
#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "VModdableBlueprintInterface.generated.h"

UINTERFACE()
class ALTAR_API UVModdableBlueprintInterface : public UInterface {
    GENERATED_BODY()
};

class ALTAR_API IVModdableBlueprintInterface : public IInterface {
    GENERATED_BODY()
public:
};

