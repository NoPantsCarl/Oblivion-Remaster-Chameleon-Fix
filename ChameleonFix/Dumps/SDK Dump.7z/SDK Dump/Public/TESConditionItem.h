#pragma once
#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "TESConditionItem.generated.h"

UCLASS(Blueprintable, Transient)
class ALTAR_API UTESConditionItem : public UObject {
    GENERATED_BODY()
public:
    UTESConditionItem();

};

