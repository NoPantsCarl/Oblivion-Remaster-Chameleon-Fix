#pragma once
#include "CoreMinimal.h"
#include "TESBoundObject.h"
#include "TESLevItem.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UTESLevItem : public UTESBoundObject {
    GENERATED_BODY()
public:
    UTESLevItem();

};

