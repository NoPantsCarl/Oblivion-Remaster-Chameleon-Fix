#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "VAnimNotify_HitMelee.generated.h"

UCLASS(Blueprintable, CollapseCategories)
class ALTAR_API UVAnimNotify_HitMelee : public UAnimNotify {
    GENERATED_BODY()
public:
    UVAnimNotify_HitMelee();

};

