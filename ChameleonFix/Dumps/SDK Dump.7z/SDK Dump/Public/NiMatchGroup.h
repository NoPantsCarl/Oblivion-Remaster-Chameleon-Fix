#pragma once
#include "CoreMinimal.h"
#include "NifType.h"
#include "NiMatchGroup.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiMatchGroup : public UNifType {
    GENERATED_BODY()
public:
    UNiMatchGroup();

};

