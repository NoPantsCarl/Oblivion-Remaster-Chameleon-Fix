#pragma once
#include "CoreMinimal.h"
#include "TESForm.h"
#include "TESPackage.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UTESPackage : public UTESForm {
    GENERATED_BODY()
public:
    UTESPackage();

};

