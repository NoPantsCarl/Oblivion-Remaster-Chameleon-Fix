#pragma once
#include "CoreMinimal.h"
#include "NiGeometry.h"
#include "NiTriBasedGeom.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiTriBasedGeom : public UNiGeometry {
    GENERATED_BODY()
public:
    UNiTriBasedGeom();

};

