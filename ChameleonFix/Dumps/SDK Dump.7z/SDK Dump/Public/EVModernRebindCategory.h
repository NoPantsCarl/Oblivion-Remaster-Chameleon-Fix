#pragma once
#include "CoreMinimal.h"
#include "EVModernRebindCategory.generated.h"

UENUM(BlueprintType)
enum class EVModernRebindCategory : uint8 {
    General,
    UI_Navigation,
};

