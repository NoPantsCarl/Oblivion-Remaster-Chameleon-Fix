#pragma once
#include "CoreMinimal.h"
#include "ACTOR_FACTION_RANK.generated.h"

USTRUCT(BlueprintType)
struct ALTAR_API FACTOR_FACTION_RANK {
    GENERATED_BODY()
public:
    FACTOR_FACTION_RANK();
};

