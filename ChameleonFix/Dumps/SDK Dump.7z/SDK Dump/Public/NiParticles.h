#pragma once
#include "CoreMinimal.h"
#include "NiGeometry.h"
#include "NiParticles.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiParticles : public UNiGeometry {
    GENERATED_BODY()
public:
    UNiParticles();

};

