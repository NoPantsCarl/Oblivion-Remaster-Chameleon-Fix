#pragma once
#include "CoreMinimal.h"
#include "NiSingleInterpController.h"
#include "NiPoint3InterpController.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiPoint3InterpController : public UNiSingleInterpController {
    GENERATED_BODY()
public:
    UNiPoint3InterpController();

};

