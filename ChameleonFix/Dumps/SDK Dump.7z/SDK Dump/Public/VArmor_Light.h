#pragma once
#include "CoreMinimal.h"
#include "VArmor.h"
#include "VArmor_Light.generated.h"

UCLASS(Blueprintable)
class ALTAR_API AVArmor_Light : public AVArmor {
    GENERATED_BODY()
public:
    AVArmor_Light(const FObjectInitializer& ObjectInitializer);

};

