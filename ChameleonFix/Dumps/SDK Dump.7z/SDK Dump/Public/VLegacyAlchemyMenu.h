#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyAlchemyMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyAlchemyMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyAlchemyMenu();

};

