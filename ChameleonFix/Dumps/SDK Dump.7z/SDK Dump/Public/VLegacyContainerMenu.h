#pragma once
#include "CoreMinimal.h"
#include "VLegacyInventoryMenu.h"
#include "VLegacyContainerMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyContainerMenu : public UVLegacyInventoryMenu {
    GENERATED_BODY()
public:
    UVLegacyContainerMenu();

};

