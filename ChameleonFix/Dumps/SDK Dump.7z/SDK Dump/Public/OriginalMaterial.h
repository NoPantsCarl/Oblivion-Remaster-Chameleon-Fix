#pragma once
#include "CoreMinimal.h"
#include "OriginalMaterial.generated.h"

USTRUCT(BlueprintType)
struct FOriginalMaterial {
    GENERATED_BODY()
public:
    ALTAR_API FOriginalMaterial();
};

