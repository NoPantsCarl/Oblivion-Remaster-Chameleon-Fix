#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyQuantityMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyQuantityMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyQuantityMenu();

};

