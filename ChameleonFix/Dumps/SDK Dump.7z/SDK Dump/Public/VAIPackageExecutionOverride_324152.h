#pragma once
#include "CoreMinimal.h"
#include "VAIPackageExecutionOverride.h"
#include "VAIPackageExecutionOverride_324152.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UVAIPackageExecutionOverride_324152 : public UVAIPackageExecutionOverride {
    GENERATED_BODY()
public:
    UVAIPackageExecutionOverride_324152();

};

