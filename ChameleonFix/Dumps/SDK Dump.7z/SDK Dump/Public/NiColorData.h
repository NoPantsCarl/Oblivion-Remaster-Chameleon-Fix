#pragma once
#include "CoreMinimal.h"
#include "NiObject.h"
#include "NiColorData.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiColorData : public UNiObject {
    GENERATED_BODY()
public:
    UNiColorData();

};

