#pragma once
#include "CoreMinimal.h"
#include "Components/ContentWidget.h"
#include "VATMPlayingWidget.generated.h"

UCLASS(Blueprintable)
class UVATMPlayingWidget : public UContentWidget {
    GENERATED_BODY()
public:
    UVATMPlayingWidget();

};

