#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyRepairMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyRepairMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyRepairMenu();

};

