#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacySaveLoadMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacySaveLoadMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacySaveLoadMenu();

};

