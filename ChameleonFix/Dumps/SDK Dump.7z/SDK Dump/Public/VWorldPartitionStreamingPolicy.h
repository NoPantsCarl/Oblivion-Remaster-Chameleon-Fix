/* FIXME - irrelevant really
#pragma once
#include "CoreMinimal.h"
#include "WorldPartition/WorldPartitionLevelStreamingPolicy.h"
#include "VWorldPartitionStreamingPolicy.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UVWorldPartitionStreamingPolicy : public UWorldPartitionLevelStreamingPolicy {
    GENERATED_BODY()
public:
    UVWorldPartitionStreamingPolicy();

};
*/