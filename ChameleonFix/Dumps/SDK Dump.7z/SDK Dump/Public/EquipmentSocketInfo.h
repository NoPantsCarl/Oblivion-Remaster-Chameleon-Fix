#pragma once
#include "CoreMinimal.h"
#include "EquipmentSocketInfo.generated.h"

USTRUCT(BlueprintType)
struct FEquipmentSocketInfo {
    GENERATED_BODY()
public:
    ALTAR_API FEquipmentSocketInfo();
};

