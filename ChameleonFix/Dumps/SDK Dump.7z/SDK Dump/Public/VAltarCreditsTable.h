#pragma once
#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "VAltarCreditsTable.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UVAltarCreditsTable : public UDataTable {
    GENERATED_BODY()
public:
    UVAltarCreditsTable();

};

