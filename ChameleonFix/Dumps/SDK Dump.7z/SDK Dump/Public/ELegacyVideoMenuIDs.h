#pragma once
#include "CoreMinimal.h"
#include "ELegacyVideoMenuIDs.generated.h"

UENUM(BlueprintType)
enum class ELegacyVideoMenuIDs : uint8 {
    None,
    Return,
};

