#pragma once
#include "CoreMinimal.h"
#include "FLegacyMainMenuLogo.generated.h"

UENUM(BlueprintType)
enum class FLegacyMainMenuLogo : uint8 {
    None,
    Blink,
    Final,
};

