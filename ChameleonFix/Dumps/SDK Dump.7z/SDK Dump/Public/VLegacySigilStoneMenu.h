#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacySigilStoneMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacySigilStoneMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacySigilStoneMenu();

};

