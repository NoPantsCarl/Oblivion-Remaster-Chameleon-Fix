#pragma once
#include "CoreMinimal.h"
#include "NiPSysModifierFloatCtlr.h"
#include "NiPSysEmitterInitialRadiusCtlr.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiPSysEmitterInitialRadiusCtlr : public UNiPSysModifierFloatCtlr {
    GENERATED_BODY()
public:
    UNiPSysEmitterInitialRadiusCtlr();

};

