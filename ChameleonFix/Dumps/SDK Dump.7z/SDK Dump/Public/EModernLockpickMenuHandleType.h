#pragma once
#include "CoreMinimal.h"
#include "EModernLockpickMenuHandleType.generated.h"

UENUM(BlueprintType)
enum class EModernLockpickMenuHandleType : uint8 {
    Normal,
    Skeleton,
};

