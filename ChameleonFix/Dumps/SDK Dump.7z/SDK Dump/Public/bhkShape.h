#pragma once
#include "CoreMinimal.h"
#include "bhkSerializable.h"
#include "bhkShape.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UbhkShape : public UbhkSerializable {
    GENERATED_BODY()
public:
    UbhkShape();

};

