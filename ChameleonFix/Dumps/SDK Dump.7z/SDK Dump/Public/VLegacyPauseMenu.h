#pragma once
#include "CoreMinimal.h"
#include "VAltarMenu.h"
#include "VLegacyPauseMenu.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class ALTAR_API UVLegacyPauseMenu : public UVAltarMenu {
    GENERATED_BODY()
public:
    UVLegacyPauseMenu();

};

