#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "VUISaveSystem.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UVUISaveSystem : public UGameInstanceSubsystem {
    GENERATED_BODY()
public:
    UVUISaveSystem();

};

