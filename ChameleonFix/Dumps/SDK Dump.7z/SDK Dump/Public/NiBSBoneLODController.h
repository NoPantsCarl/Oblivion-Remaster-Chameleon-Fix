#pragma once
#include "CoreMinimal.h"
#include "NiBoneLODController.h"
#include "NiBSBoneLODController.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiBSBoneLODController : public UNiBoneLODController {
    GENERATED_BODY()
public:
    UNiBSBoneLODController();

};

