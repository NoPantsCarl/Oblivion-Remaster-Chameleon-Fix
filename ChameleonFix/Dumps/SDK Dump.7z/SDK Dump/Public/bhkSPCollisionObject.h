#pragma once
#include "CoreMinimal.h"
#include "bhkPCollisionObject.h"
#include "bhkSPCollisionObject.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UbhkSPCollisionObject : public UbhkPCollisionObject {
    GENERATED_BODY()
public:
    UbhkSPCollisionObject();

};

