#pragma once
#include "CoreMinimal.h"
#include "EVGlobalMusicState.generated.h"

UENUM(BlueprintType)
enum class EVGlobalMusicState : uint8 {
    Normal,
    None,
};

