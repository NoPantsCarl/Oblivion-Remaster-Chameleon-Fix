#pragma once
#include "CoreMinimal.h"
#include "VPontoonGenerationDecision.generated.h"

USTRUCT(BlueprintType)
struct ALTAR_API FVPontoonGenerationDecision {
    GENERATED_BODY()
public:
    FVPontoonGenerationDecision();
};

