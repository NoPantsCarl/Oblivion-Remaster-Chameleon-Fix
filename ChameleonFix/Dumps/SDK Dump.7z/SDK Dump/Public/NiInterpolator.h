#pragma once
#include "CoreMinimal.h"
#include "NiObject.h"
#include "NiInterpolator.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiInterpolator : public UNiObject {
    GENERATED_BODY()
public:
    UNiInterpolator();

};

