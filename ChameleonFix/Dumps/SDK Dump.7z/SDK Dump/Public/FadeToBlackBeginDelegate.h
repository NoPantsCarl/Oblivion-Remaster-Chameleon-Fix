#pragma once
#include "CoreMinimal.h"
#include "FadeToBlackBeginDelegate.generated.h"

UDELEGATE(BlueprintCallable) DECLARE_DYNAMIC_MULTICAST_DELEGATE(FFadeToBlackBegin);

