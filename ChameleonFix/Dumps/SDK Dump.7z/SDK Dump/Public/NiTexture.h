#pragma once
#include "CoreMinimal.h"
#include "NiObjectNet.h"
#include "NiTexture.generated.h"

UCLASS(Blueprintable)
class ALTAR_API UNiTexture : public UNiObjectNet {
    GENERATED_BODY()
public:
    UNiTexture();

};

