---@meta

---@class UBP_XBOX_GamepadControllerData_C : UCommonInputBaseControllerData
local UBP_XBOX_GamepadControllerData_C = {}


