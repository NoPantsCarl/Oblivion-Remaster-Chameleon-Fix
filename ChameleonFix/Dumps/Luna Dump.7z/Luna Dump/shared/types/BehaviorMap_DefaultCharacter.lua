---@meta

---@class UBehaviorMap_DefaultCharacter_C : UBehaviorMap_DefaultPawn_C
local UBehaviorMap_DefaultCharacter_C = {}


