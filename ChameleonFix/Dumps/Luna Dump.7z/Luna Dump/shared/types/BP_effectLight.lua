---@meta

---@class UBP_effectLight_C : UTESEffectShader
local UBP_effectLight_C = {}


