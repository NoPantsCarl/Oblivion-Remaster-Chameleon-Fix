---@meta

---@class ABP_PF_prisoncelltorch01_Act_C : ABP_Prefab_Fires_Act_C
local ABP_PF_prisoncelltorch01_Act_C = {}


