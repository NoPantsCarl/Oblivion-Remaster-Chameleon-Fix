---@meta

---@class ABP_Generic_BDP_UB_FullArmor_C : ABP_Generic_BDP_UpperBody_C
---@field BPC_WeapBloodSplatter UBPC_WeapBloodSplatter_C
local ABP_Generic_BDP_UB_FullArmor_C = {}



