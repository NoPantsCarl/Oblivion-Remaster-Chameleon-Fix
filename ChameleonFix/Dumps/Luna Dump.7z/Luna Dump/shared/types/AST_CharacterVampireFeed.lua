---@meta

---@class UAST_CharacterVampireFeed_C : UVAltarActionState
---@field UberGraphFrame FPointerToUberGraphFrame
---@field FeedAnim UAnimSequence
local UAST_CharacterVampireFeed_C = {}

function UAST_CharacterVampireFeed_C:SetupFeedDockingData() end
function UAST_CharacterVampireFeed_C:OnCanceled_FD70707943857F386BCB3E92ED2574B6() end
function UAST_CharacterVampireFeed_C:OnCompleted_FD70707943857F386BCB3E92ED2574B6() end
function UAST_CharacterVampireFeed_C:OnEntered() end
function UAST_CharacterVampireFeed_C:OnExited() end
---@param EntryPoint int32
function UAST_CharacterVampireFeed_C:ExecuteUbergraph_AST_CharacterVampireFeed(EntryPoint) end


