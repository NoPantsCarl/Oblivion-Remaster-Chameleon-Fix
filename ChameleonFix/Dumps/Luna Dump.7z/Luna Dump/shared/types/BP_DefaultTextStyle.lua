---@meta

---@class UBP_DefaultTextStyle_C : UCommonTextStyle
local UBP_DefaultTextStyle_C = {}


