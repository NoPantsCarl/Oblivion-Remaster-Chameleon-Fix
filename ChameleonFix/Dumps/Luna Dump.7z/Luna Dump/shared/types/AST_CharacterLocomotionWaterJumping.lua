---@meta

---@class UAST_CharacterLocomotionWaterJumping_C : UVState
---@field UberGraphFrame FPointerToUberGraphFrame
local UAST_CharacterLocomotionWaterJumping_C = {}

function UAST_CharacterLocomotionWaterJumping_C:OnEntered() end
function UAST_CharacterLocomotionWaterJumping_C:OnExited() end
---@param EntryPoint int32
function UAST_CharacterLocomotionWaterJumping_C:ExecuteUbergraph_AST_CharacterLocomotionWaterJumping(EntryPoint) end


