---@meta

---@class UAST_CharacterActionInactive_C : UAST_CharacterSingleActionState_C
local UAST_CharacterActionInactive_C = {}


