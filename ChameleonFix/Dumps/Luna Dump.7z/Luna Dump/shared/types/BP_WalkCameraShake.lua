---@meta

---@class UBP_WalkCameraShake_C : ULegacyCameraShake
local UBP_WalkCameraShake_C = {}


