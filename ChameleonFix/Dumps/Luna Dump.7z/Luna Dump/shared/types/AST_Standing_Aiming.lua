---@meta

---@class UAST_Standing_Aiming_C : UAST_CameraBase_C
local UAST_Standing_Aiming_C = {}


