---@meta

---@class UAltarActionWidget_C : UVAltarActionWidget
local UAltarActionWidget_C = {}


