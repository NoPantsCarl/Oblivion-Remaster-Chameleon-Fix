---@meta

---@class UWBP_Modern_MapFilterNavigableScrollBox_C : UVAltarNavigableScrollBox
local UWBP_Modern_MapFilterNavigableScrollBox_C = {}


