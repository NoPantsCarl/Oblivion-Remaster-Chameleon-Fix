---@meta

---@class IALI_HorseRidingInAir_C : IAnimLayerInterface
local IALI_HorseRidingInAir_C = {}

---@param InPose FPoseLink
---@param HorseRidingInAirLayer FPoseLink
function IALI_HorseRidingInAir_C:HorseRidingInAirLayer(InPose, HorseRidingInAirLayer) end


