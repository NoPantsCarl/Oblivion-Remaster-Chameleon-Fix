---@meta

---@class UWBP_List_EmptyLabel_C : UUserWidget
local UWBP_List_EmptyLabel_C = {}


