---@meta

---@class UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase
---@field AmbisonicsOrder int32
local UAmbisonicsEncodingSettings = {}



