---@meta

---@class UBP_RunCameraShake_FP_C : ULegacyCameraShake
local UBP_RunCameraShake_FP_C = {}


