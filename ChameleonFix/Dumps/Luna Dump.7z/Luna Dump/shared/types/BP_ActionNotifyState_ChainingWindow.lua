---@meta

---@class UBP_ActionNotifyState_ChainingWindow_C : UVAnimNotify_ActionNotifyState
---@field OptionalExtraDelay double
local UBP_ActionNotifyState_ChainingWindow_C = {}

---@return FString
function UBP_ActionNotifyState_ChainingWindow_C:GetNotifyName() end


