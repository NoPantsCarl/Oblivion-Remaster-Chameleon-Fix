---@meta

---@class UAST_OnDrawingWeapon_C : UAST_CameraBase_C
local UAST_OnDrawingWeapon_C = {}


