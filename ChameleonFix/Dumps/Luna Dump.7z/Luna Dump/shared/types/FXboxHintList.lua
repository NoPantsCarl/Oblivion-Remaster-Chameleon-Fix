---@meta

---@class FFXboxHintList
---@field XboxHint_13_53680FB543A3A59B5BE2FFA499E72922 TArray<FFFloatingHintXbox>
local FFXboxHintList = {}



