---@meta

---@class UASM_Swimming_Bow_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_Swimming_Bow_C = {}

---@param EntryPoint int32
function UASM_Swimming_Bow_C:ExecuteUbergraph_ASM_Swimming_Bow(EntryPoint) end


