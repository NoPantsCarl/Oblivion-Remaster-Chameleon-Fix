---@meta

---@class UAST_OnHorseWalking_C : UAST_CameraBase_C
local UAST_OnHorseWalking_C = {}


