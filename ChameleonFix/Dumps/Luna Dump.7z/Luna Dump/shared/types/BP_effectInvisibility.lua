---@meta

---@class UBP_effectInvisibility_C : UTESEffectShader
local UBP_effectInvisibility_C = {}


