---@meta

---@class FStruct_Stagger_Swim
---@field Stagger_8_B7C3F60143114E06D8EF8EAB8E5A4FE0 UAnimMontage
---@field Swim_Stagger_9_DC8B6E214555B6C72ED2F8BC3507D3A3 UAnimMontage
local FStruct_Stagger_Swim = {}



