---@enum EN_CreatureSpecies
local EN_CreatureSpecies = {
    NewEnumerator2 = 0,
    NewEnumerator0 = 1,
    NewEnumerator1 = 2,
    EN_MAX = 3,
}

