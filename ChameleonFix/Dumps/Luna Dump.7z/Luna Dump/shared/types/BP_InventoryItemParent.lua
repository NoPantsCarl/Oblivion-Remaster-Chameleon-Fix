---@meta

---@class ABP_InventoryItemParent_C : AActor
---@field DefaultSceneRoot USceneComponent
local ABP_InventoryItemParent_C = {}



