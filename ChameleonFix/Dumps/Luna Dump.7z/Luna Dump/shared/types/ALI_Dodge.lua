---@meta

---@class IALI_Dodge_C : IAnimLayerInterface
local IALI_Dodge_C = {}

---@param DodgeLayer FPoseLink
function IALI_Dodge_C:DodgeLayer(DodgeLayer) end


