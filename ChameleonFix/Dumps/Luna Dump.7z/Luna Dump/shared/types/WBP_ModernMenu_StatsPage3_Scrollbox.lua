---@meta

---@class UWBP_ModernMenu_StatsPage3_Scrollbox_C : UVAltarNavigableScrollBox
---@field UberGraphFrame FPointerToUberGraphFrame
local UWBP_ModernMenu_StatsPage3_Scrollbox_C = {}

---@param IsDesignTime boolean
function UWBP_ModernMenu_StatsPage3_Scrollbox_C:PreConstruct(IsDesignTime) end
function UWBP_ModernMenu_StatsPage3_Scrollbox_C:Construct() end
---@param bNewInputType ECommonInputType
function UWBP_ModernMenu_StatsPage3_Scrollbox_C:OnInputMethodChanged(bNewInputType) end
---@param EntryPoint int32
function UWBP_ModernMenu_StatsPage3_Scrollbox_C:ExecuteUbergraph_WBP_ModernMenu_StatsPage3_Scrollbox(EntryPoint) end


