---@enum FluidDynamicForceMeshType
local FluidDynamicForceMeshType = {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    FluidDynamicForceMeshType_MAX = 2,
}

