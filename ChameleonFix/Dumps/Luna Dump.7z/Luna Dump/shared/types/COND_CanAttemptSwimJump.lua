---@meta

---@class UCOND_CanAttemptSwimJump_C : UCOND_Parent_C
local UCOND_CanAttemptSwimJump_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_CanAttemptSwimJump_C:CheckCondition(CurrentState) end


