---@meta

---@class IALI_HumanoidTailPhysics_C : IAnimLayerInterface
local IALI_HumanoidTailPhysics_C = {}

---@param InPose FPoseLink
---@param Humanoid_Tail_Physics FPoseLink
IALI_HumanoidTailPhysics_C['Humanoid Tail Physics'] = function(self, InPose, Humanoid_Tail_Physics) end


