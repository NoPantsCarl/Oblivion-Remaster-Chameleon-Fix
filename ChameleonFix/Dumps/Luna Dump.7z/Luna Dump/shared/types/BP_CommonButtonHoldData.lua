---@meta

---@class UBP_CommonButtonHoldData_C : UCommonUIHoldData
local UBP_CommonButtonHoldData_C = {}


