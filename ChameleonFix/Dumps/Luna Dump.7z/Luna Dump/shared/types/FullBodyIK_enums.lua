---@enum EFBIKBoneLimitType
local EFBIKBoneLimitType = {
    Free = 0,
    Limit = 1,
    Locked = 2,
    EFBIKBoneLimitType_MAX = 3,
}

---@enum EPoleVectorOption
local EPoleVectorOption = {
    Direction = 0,
    Location = 1,
    EPoleVectorOption_MAX = 2,
}

