---@enum EEmissiveLightType
local EEmissiveLightType = {
    Plane = 0,
    Sphere = 1,
    EEmissiveLightType_MAX = 2,
}

