---@enum BPE_ClothingInstanceType
local BPE_ClothingInstanceType = {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    BPE_MAX = 3,
}

