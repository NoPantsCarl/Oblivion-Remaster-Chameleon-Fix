---@meta

---@class UAST_Sneaking_Zooming_C : UAST_CameraBase_C
local UAST_Sneaking_Zooming_C = {}


