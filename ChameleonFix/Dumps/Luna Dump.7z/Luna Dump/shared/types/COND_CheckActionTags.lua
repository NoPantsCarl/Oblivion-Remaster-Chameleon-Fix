---@meta

---@class UCOND_CheckActionTags_C : UVAltarStateConditionCheckActionTags
local UCOND_CheckActionTags_C = {}


