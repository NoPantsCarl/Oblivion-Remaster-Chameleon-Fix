---@meta

---@class UNQF_FollowPlayerCharacter_C : UNavigationQueryFilter
local UNQF_FollowPlayerCharacter_C = {}


