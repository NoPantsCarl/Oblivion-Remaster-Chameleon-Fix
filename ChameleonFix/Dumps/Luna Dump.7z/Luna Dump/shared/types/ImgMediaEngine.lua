---@meta

---@class UDEPRECATED_ImgMediaPlaybackComponent : UActorComponent
---@field LODBias float
local UDEPRECATED_ImgMediaPlaybackComponent = {}



