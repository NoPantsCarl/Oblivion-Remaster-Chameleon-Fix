---@meta

---@class UNiagaraDataInterfaceWwiseEvent : UNiagaraDataInterface
---@field EventToPost UAkAudioEvent
---@field GameParameters TArray<UAkRtpc>
---@field bLimitPostsPerTick boolean
---@field MaxPostsPerTick int32
---@field bStopWhenComponentIsDestroyed boolean
local UNiagaraDataInterfaceWwiseEvent = {}



