---@meta

---@class UCOND_HasShieldEquipped_C : UCOND_Parent_C
local UCOND_HasShieldEquipped_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_HasShieldEquipped_C:CheckCondition(CurrentState) end


