---@meta

---@class UASM_CharacterLocomotionSwimming_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_CharacterLocomotionSwimming_C = {}

function UASM_CharacterLocomotionSwimming_C:OnEntered() end
---@param EntryPoint int32
function UASM_CharacterLocomotionSwimming_C:ExecuteUbergraph_ASM_CharacterLocomotionSwimming(EntryPoint) end


