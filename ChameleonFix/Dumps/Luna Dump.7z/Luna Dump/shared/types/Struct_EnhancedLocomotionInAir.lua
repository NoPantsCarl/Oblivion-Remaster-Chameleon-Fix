---@meta

---@class FStruct_EnhancedLocomotionInAir
---@field JumpingInPlace_2_F47556224E3DE6ADDE13549C6DA50B90 UAnimSequenceBase
---@field JumpingLeftFoot_4_76629CE5434E8181DD24329894B241CD UAnimSequenceBase
---@field JumpingRightFoot_6_57FCC5C741E78ED680CA129E5CE03ACB UAnimSequenceBase
---@field InAirInPlace_8_40B4B44E43E2B5308695A4A622489727 UAnimSequenceBase
---@field InAirLeftFoot_11_C58B0BAE4289A41EE7CD32B2C565EC43 UAnimSequenceBase
---@field InAirRightFoot_13_F45402EE486B7FB5F5585F949616BA6A UAnimSequenceBase
---@field LandInPlace_15_726909154F1536DE9B5D4490F4C86A6A UAnimSequenceBase
---@field LandToSneak_17_A3692DFD4B19DC2F1D8336A9F53AD8ED UAnimSequenceBase
local FStruct_EnhancedLocomotionInAir = {}



