---@meta

---@class UWBP_ModernMenu_Gamertag_C : UCommonUserWidget
---@field gamertag_text UWBP_AltarTextBlock_C
local UWBP_ModernMenu_Gamertag_C = {}

---@param NewGamerTag FText
function UWBP_ModernMenu_Gamertag_C:SetGamerTagText(NewGamerTag) end


