---@meta

---@class UBP_effectDarkness_C : UTESEffectShader
local UBP_effectDarkness_C = {}


