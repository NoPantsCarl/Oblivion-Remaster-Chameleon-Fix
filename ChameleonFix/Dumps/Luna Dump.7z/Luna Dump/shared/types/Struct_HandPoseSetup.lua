---@meta

---@class FStruct_HandPoseSetup
---@field HandPoseShield_23_8CC54CF943E310F9EB143692F7C1AC28 UAnimSequenceBase
---@field HandBoneName_5_85A2BB4E49802AE979A061A15C127794 FName
---@field HandBlendDepth_6_E610B3014047B45A6A7330933340B632 int32
---@field HandBlendTime_31_80625F9B4C28F923E30CE2A98B1B2AA2 double
local FStruct_HandPoseSetup = {}



