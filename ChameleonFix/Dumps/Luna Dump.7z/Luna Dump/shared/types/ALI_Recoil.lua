---@meta

---@class IALI_Recoil_C : IAnimLayerInterface
local IALI_Recoil_C = {}

---@param InPose FPoseLink
---@param RecoilLayer FPoseLink
function IALI_Recoil_C:RecoilLayer(InPose, RecoilLayer) end


