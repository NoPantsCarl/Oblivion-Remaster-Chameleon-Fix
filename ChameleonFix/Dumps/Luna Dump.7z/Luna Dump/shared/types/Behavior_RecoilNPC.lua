---@meta

---@class UBehavior_RecoilNPC_C : UVActorBehaviorBase
---@field UberGraphFrame FPointerToUberGraphFrame
local UBehavior_RecoilNPC_C = {}

function UBehavior_RecoilNPC_C:OnCanceled_C0F056024C47A2D0575EE7B40BD69D84() end
function UBehavior_RecoilNPC_C:OnCompleted_C0F056024C47A2D0575EE7B40BD69D84() end
---@param bInterrupted boolean
function UBehavior_RecoilNPC_C:OnEnd(bInterrupted) end
function UBehavior_RecoilNPC_C:OnInit() end
---@param EntryPoint int32
function UBehavior_RecoilNPC_C:ExecuteUbergraph_Behavior_RecoilNPC(EntryPoint) end


