---@meta

---@class FAnimBlueprintGeneratedConstantData : FAnimBlueprintGeneratedConstantData
local FAnimBlueprintGeneratedConstantData = {}


---@class UABP_Reverse_Bow_C : UTABP_Reverse_Bow_Generic_C
local UABP_Reverse_Bow_C = {}


