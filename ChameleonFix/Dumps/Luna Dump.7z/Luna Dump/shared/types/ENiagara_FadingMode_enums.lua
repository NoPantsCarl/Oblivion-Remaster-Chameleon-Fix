---@enum ENiagara_FadingMode
local ENiagara_FadingMode = {
    NewEnumerator0 = 0,
    NewEnumerator3 = 1,
    NewEnumerator1 = 2,
    NewEnumerator2 = 3,
    NewEnumerator5 = 4,
    ENiagara_MAX = 5,
}

