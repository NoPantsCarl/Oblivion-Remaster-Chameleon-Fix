---@meta

---@class ABP_WeaponShieldPlaceholder_C : AVShield
local ABP_WeaponShieldPlaceholder_C = {}


