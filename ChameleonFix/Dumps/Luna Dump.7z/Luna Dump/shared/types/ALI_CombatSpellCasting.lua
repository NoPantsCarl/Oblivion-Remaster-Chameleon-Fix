---@meta

---@class IALI_CombatSpellCasting_C : IAnimLayerInterface
local IALI_CombatSpellCasting_C = {}

---@param SpellCastingLayer FPoseLink
function IALI_CombatSpellCasting_C:SpellCastingLayer(SpellCastingLayer) end


