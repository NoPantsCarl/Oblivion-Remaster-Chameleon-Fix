---@meta

---@class UBP_SettingRichTextDecorator_C : URichTextBlockImageDecorator
local UBP_SettingRichTextDecorator_C = {}


