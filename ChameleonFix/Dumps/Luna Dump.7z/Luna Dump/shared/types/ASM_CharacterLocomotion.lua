---@meta

---@class UASM_CharacterLocomotion_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_CharacterLocomotion_C = {}

---@param EntryPoint int32
function UASM_CharacterLocomotion_C:ExecuteUbergraph_ASM_CharacterLocomotion(EntryPoint) end


