---@meta

---@class UBehaviorMap_Creature_Ghosts_C : UBehaviorMap_DefaultCreature_C
local UBehaviorMap_Creature_Ghosts_C = {}


