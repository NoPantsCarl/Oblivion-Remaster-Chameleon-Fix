---@meta

---@class UBP_PS5_GamepadControllerData1_C : UCommonInputBaseControllerData
local UBP_PS5_GamepadControllerData1_C = {}


