---@meta

---@class UASM_CharacterAction_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_CharacterAction_C = {}

---@param EntryPoint int32
function UASM_CharacterAction_C:ExecuteUbergraph_ASM_CharacterAction(EntryPoint) end


