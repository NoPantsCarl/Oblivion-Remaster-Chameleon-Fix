---@meta

---@class UWBP_ModernBossBackground_C : UCommonUserWidget
---@field Image_118 UImage
---@field Left UImage
---@field LeftFill UImage
---@field Middle UImage
---@field Right UImage
---@field RightFill UImage
local UWBP_ModernBossBackground_C = {}



