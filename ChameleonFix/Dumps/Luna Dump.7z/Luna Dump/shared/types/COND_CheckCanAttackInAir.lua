---@meta

---@class UCOND_CheckCanAttackInAir_C : UCOND_CheckSkillAndAnimTag_C
local UCOND_CheckCanAttackInAir_C = {}


