---@enum EOpenColorIOViewTransformDirection
local EOpenColorIOViewTransformDirection = {
    Forward = 0,
    Inverse = 1,
    EOpenColorIOViewTransformDirection_MAX = 2,
}

