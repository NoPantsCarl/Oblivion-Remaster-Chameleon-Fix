---@meta

---@class IALI_FeetIK_C : IAnimLayerInterface
local IALI_FeetIK_C = {}

---@param AnimationPose FPoseLink
---@param FeetIKLayer FPoseLink
function IALI_FeetIK_C:FeetIKLayer(AnimationPose, FeetIKLayer) end


