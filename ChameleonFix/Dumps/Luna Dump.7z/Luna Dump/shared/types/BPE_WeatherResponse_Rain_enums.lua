---@enum BPE_WeatherResponse_Rain
local BPE_WeatherResponse_Rain = {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    BPE_WeatherResponse_MAX = 3,
}

