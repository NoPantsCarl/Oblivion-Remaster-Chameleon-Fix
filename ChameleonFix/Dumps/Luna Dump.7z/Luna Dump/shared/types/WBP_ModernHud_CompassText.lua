---@meta

---@class UWBP_ModernHud_CompassText_C : UCommonUserWidget
---@field DistanceText UCommonRichTextBlock
---@field TextPositionCurve UCurveFloat
local UWBP_ModernHud_CompassText_C = {}

---@param InText FText
function UWBP_ModernHud_CompassText_C:SetText(InText) end


