---@meta

---@class UBP_ActionNotifyState_TagContainer_C : UVAnimNotify_ActionNotifyState
---@field ['Tags To Transmit'] FGameplayTagContainer
local UBP_ActionNotifyState_TagContainer_C = {}



