---@meta

---@class UNQF_CanOnlySwim_C : UNavigationQueryFilter
local UNQF_CanOnlySwim_C = {}


