---@meta

---@class ABP_BDP_LC_05_shirt_C : ABP_Generic_BDP_UB_Shirt_C
---@field ChaosCloth_0 UChaosClothComponent
---@field IsSimulating_0 boolean
local ABP_BDP_LC_05_shirt_C = {}



