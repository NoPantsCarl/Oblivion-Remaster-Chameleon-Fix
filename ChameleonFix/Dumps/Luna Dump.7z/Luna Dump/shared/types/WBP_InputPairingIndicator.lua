---@meta

---@class UWBP_InputPairingIndicator_C : UUserWidget
---@field InputPairingIndicatorText UTextBlock
local UWBP_InputPairingIndicator_C = {}

---@param Active boolean
function UWBP_InputPairingIndicator_C:SetInputPairingActive(Active) end


