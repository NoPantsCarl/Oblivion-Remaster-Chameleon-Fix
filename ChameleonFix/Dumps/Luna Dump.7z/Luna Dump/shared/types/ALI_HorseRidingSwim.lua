---@meta

---@class IALI_HorseRidingSwim_C : IAnimLayerInterface
local IALI_HorseRidingSwim_C = {}

---@param InPose FPoseLink
---@param HorseRidingSwimLayer FPoseLink
function IALI_HorseRidingSwim_C:HorseRidingSwimLayer(InPose, HorseRidingSwimLayer) end


