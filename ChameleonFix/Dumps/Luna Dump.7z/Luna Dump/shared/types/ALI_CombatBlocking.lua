---@meta

---@class IALI_CombatBlocking_C : IAnimLayerInterface
local IALI_CombatBlocking_C = {}

---@param BlockingLayer FPoseLink
function IALI_CombatBlocking_C:BlockingLayer(BlockingLayer) end


