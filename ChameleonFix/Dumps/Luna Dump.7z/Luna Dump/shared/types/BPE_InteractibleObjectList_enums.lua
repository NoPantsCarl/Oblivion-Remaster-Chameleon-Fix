---@enum BPE_InteractibleObjectList
local BPE_InteractibleObjectList = {
    NewEnumerator1 = 0,
    NewEnumerator2 = 1,
    NewEnumerator3 = 2,
    NewEnumerator5 = 3,
    NewEnumerator6 = 4,
    BPE_MAX = 5,
}

