---@meta

---@class FStruct_LocomotionTurn
---@field BlendSpace_Moving_37_73A9965B4B03044D8136D4AA143711EC UBlendSpace
---@field Turn_Left_44_6ADD2A4343BD6CF0B64E8AB8931EB976 UAnimSequenceBase
---@field Turn_Right_45_808C167846C1194D78D3DBBA5B8E0B51 UAnimSequence
---@field Blendspace_Turning_48_4A48DAD44023C36FF6E68190BD0C9DFB UBlendSpace
local FStruct_LocomotionTurn = {}



