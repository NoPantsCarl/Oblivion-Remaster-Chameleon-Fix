---@meta

---@class FFieldNotificationId
---@field FieldName FName
local FFieldNotificationId = {}



---@class INotifyFieldValueChanged : IInterface
local INotifyFieldValueChanged = {}


