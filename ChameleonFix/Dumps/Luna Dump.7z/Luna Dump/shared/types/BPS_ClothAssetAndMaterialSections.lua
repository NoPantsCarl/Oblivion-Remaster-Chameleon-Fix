---@meta

---@class FBPS_ClothAssetAndMaterialSections
---@field clothasset_2_9F04255C4A2BA22EADE9F6BCFB886F38 UChaosClothAsset
---@field materialsectionstohideonrootskeletalmesh_12_5467CB894452B9B8A8C3C8A5D73ACE10 TSet<int32>
local FBPS_ClothAssetAndMaterialSections = {}



