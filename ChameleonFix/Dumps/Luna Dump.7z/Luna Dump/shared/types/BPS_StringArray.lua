---@meta

---@class FBPS_StringArray
---@field LevelName_20_A72F782C4A8435849253709EBF2C6BA0 FString
---@field ChangeWeatheroverride_21_97B3AF6246848E8A9510E0B1376952A7 boolean
---@field ChangeWindRotation_29_1DE7870A430847C9041C9997364D4775 boolean
---@field WindRotation_26_4D51B1E1488D05532384DCA0762EEFBA double
---@field ChangeWindIntensity_30_1BABA61C4679882D54D471B2BF91C19B boolean
---@field WindIntensity_24_525A71EC429A8EFBCC7D2A86FC808B5E double
local FBPS_StringArray = {}



