---@meta

---@class UAvfMediaSettings : UObject
---@field NativeAudioOut boolean
local UAvfMediaSettings = {}



