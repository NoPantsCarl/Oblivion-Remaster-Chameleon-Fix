---@meta

---@class UUIActiveSpellEffectData_C : UObject
---@field Icon UTexture2D
---@field Progress double
---@field OldItem boolean
local UUIActiveSpellEffectData_C = {}



