---@enum BPE_ImpactMaterialType
local BPE_ImpactMaterialType = {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    NewEnumerator3 = 3,
    BPE_MAX = 4,
}

