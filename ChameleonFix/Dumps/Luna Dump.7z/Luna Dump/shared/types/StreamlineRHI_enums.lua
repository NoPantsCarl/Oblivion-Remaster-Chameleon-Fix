---@enum EStreamlineSettingOverride
local EStreamlineSettingOverride = {
    Enabled = 0,
    Disabled = 1,
    UseProjectSettings = 2,
    EStreamlineSettingOverride_MAX = 3,
}

