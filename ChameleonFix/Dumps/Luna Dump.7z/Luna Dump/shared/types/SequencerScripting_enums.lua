---@enum ESequenceTimeUnit
local ESequenceTimeUnit = {
    DisplayRate = 0,
    TickResolution = 1,
    ESequenceTimeUnit_MAX = 2,
}

