---@meta

---@class UCOND_IsInAir_C : UCOND_Parent_C
local UCOND_IsInAir_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsInAir_C:CheckCondition(CurrentState) end


