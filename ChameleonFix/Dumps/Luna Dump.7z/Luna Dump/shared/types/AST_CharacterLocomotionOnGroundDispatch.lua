---@meta

---@class UAST_CharacterLocomotionOnGroundDispatch_C : UVState
local UAST_CharacterLocomotionOnGroundDispatch_C = {}


