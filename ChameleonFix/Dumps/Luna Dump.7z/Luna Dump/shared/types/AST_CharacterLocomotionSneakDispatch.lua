---@meta

---@class UAST_CharacterLocomotionSneakDispatch_C : UVState
local UAST_CharacterLocomotionSneakDispatch_C = {}


