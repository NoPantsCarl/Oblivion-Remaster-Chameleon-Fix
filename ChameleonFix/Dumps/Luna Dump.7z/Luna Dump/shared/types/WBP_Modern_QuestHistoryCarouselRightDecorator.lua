---@meta

---@class UWBP_Modern_QuestHistoryCarouselRightDecorator_C : UUserWidget
---@field WBP_OriginalImageTile UWBP_OriginalImageTile_C
local UWBP_Modern_QuestHistoryCarouselRightDecorator_C = {}



