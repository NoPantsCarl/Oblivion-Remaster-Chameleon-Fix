---@meta

---@class FStruct_HumanoidLowerAndUpperBodySetup
---@field PelvisBoneName_2_9EE7B7FE4B2769D5E67E5B80B9D13038 FName
---@field PelvisBlendDepth_5_CCFACDDA420FA2FBE99F6DBFAFE382BF int32
---@field LeftLegBoneName_8_4182DA8440659573A8C179BDA73EA3CB FName
---@field RightLegBoneName_10_7CF505AE45201C0EE3165AA3FBB60113 FName
---@field LegsBlendDepth_13_A1D5A17B4DCD06C3AD7CAD87C1D9BDD3 int32
---@field UpperBodyBoneName_16_3F810894438B6DE0A3EB2BA34613E7AD FName
---@field UpperBodyBlendDepth_19_4BB5934F447E0322665173B6A82F9CC3 int32
local FStruct_HumanoidLowerAndUpperBodySetup = {}



