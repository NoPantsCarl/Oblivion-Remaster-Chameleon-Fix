---@meta

---@class UCOND_IsAliveFromUnconscious_C : UCOND_Parent_C
local UCOND_IsAliveFromUnconscious_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsAliveFromUnconscious_C:CheckCondition(CurrentState) end


