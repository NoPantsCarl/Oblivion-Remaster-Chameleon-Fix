---@meta

---@class IALI_Death_C : IAnimLayerInterface
local IALI_Death_C = {}

---@param InPose FPoseLink
---@param Death_Layer FPoseLink
IALI_Death_C['Death Layer'] = function(self, InPose, Death_Layer) end


