---@meta

---@class FStruct_Locomotion
---@field BlendSpace_Moving_37_73A9965B4B03044D8136D4AA143711EC UBlendSpace
local FStruct_Locomotion = {}



