---@meta

---@class IALI_LocomotionStanding_C : IAnimLayerInterface
local IALI_LocomotionStanding_C = {}

---@param StandingLayer FPoseLink
function IALI_LocomotionStanding_C:StandingLayer(StandingLayer) end


