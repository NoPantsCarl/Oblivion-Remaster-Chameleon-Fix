---@meta

---@class IALI_HitReact_C : IAnimLayerInterface
local IALI_HitReact_C = {}

---@param InPose FPoseLink
---@param HitReactLayer FPoseLink
function IALI_HitReact_C:HitReactLayer(InPose, HitReactLayer) end


