---@meta

---@class ABP_WeaponStaffPlaceholder_C : AVWeapon_Staff
local ABP_WeaponStaffPlaceholder_C = {}


