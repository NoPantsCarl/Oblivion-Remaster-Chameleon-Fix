---@meta

---@class UCOND_HasArrowAttached_C : UCOND_Parent_C
local UCOND_HasArrowAttached_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_HasArrowAttached_C:CheckCondition(CurrentState) end


