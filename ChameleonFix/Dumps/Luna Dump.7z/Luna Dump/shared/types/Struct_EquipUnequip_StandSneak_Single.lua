---@meta

---@class FStruct_EquipUnequip_StandSneak_Single
---@field EquipAnim_2_23C0E7FC4F6749912E8926B63A799BEA UAnimSequenceBase
---@field UnequipAnim_4_68AFFDD241209AF4997241A528788317 UAnimSequenceBase
---@field SneakEquipAnim_8_A9BD52B84CB6726850CF2499D903B870 UAnimSequenceBase
---@field SneakUnequipAnim_10_D693AECA429B436DA22B6C97E5B2D2E2 UAnimSequenceBase
local FStruct_EquipUnequip_StandSneak_Single = {}



