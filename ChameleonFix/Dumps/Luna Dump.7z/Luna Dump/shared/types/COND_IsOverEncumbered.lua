---@meta

---@class UCOND_IsOverEncumbered_C : UCOND_Parent_C
local UCOND_IsOverEncumbered_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsOverEncumbered_C:CheckCondition(CurrentState) end


