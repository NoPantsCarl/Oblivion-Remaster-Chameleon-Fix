---@meta

---@class UAudioLinkSettingsAbstract : UObject
local UAudioLinkSettingsAbstract = {}


