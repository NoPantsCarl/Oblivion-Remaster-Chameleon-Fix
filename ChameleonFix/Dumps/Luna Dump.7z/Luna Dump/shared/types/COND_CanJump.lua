---@meta

---@class UCOND_CanJump_C : UCOND_Parent_C
local UCOND_CanJump_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_CanJump_C:CheckCondition(CurrentState) end


