---@meta

---@class UASM_Standing_Bow_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_Standing_Bow_C = {}

---@param EntryPoint int32
function UASM_Standing_Bow_C:ExecuteUbergraph_ASM_Standing_Bow(EntryPoint) end


