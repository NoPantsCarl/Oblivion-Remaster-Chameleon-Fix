---@meta

---@class UWBP_InventoryBackgroundWidget_C : UVBackgroundWidgetBase
local UWBP_InventoryBackgroundWidget_C = {}


