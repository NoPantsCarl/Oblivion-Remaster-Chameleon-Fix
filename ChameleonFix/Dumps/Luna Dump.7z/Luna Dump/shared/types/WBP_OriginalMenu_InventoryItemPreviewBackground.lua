---@meta

---@class UWBP_OriginalMenu_InventoryItemPreviewBackground_C : UVBackgroundWidgetBase
---@field Preview_Background UWBP_OriginalImageTile_C
local UWBP_OriginalMenu_InventoryItemPreviewBackground_C = {}



