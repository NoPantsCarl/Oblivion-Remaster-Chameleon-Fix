---@meta

---@class UBP_effectNightEye_C : UTESEffectShader
local UBP_effectNightEye_C = {}


