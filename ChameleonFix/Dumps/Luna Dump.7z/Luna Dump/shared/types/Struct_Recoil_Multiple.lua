---@meta

---@class FStruct_Recoil_Multiple
---@field Recoil_7_60496AC34798D605A9FB29A59D1E2F6E TArray<UAnimMontage>
local FStruct_Recoil_Multiple = {}



