---@meta

---@class UAST_Swimming_Aiming_C : UAST_CameraBase_C
local UAST_Swimming_Aiming_C = {}


