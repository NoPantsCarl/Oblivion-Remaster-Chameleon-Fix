---@meta

---@class UWBP_ModernPrefab_NotificationInHUD_C : UVAltarWidget
---@field WBP_ModernPrefab_Notification UWBP_ModernPrefab_Notification_C
---@field WBP_ModernPrefab_SaveNotification UWBP_ModernPrefab_SaveNotification_C
local UWBP_ModernPrefab_NotificationInHUD_C = {}

---@param IsVisible boolean
UWBP_ModernPrefab_NotificationInHUD_C['Set Icon Background Visibility'] = function(self, IsVisible) end
UWBP_ModernPrefab_NotificationInHUD_C['Enable Notification'] = function(self, ) end


