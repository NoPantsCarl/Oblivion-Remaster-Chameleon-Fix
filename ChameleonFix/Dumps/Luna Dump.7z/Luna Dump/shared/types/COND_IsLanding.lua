---@meta

---@class UCOND_IsLanding_C : UCOND_Parent_C
local UCOND_IsLanding_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsLanding_C:CheckCondition(CurrentState) end


