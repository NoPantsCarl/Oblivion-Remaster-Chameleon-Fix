---@meta

---@class ABP_Generic_BDP_LB_Pants_C : ABP_Generic_BDP_LowerBody_C
local ABP_Generic_BDP_LB_Pants_C = {}


