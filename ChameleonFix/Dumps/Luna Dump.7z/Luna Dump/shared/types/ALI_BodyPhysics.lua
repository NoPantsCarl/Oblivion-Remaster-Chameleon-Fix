---@meta

---@class IALI_BodyPhysics_C : IAnimLayerInterface
local IALI_BodyPhysics_C = {}

---@param InPose FPoseLink
---@param BodyPhysics FPoseLink
function IALI_BodyPhysics_C:BodyPhysics(InPose, BodyPhysics) end


