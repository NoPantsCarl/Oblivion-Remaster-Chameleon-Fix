---@meta

---@class ABP_WeaponBowPlaceholder_C : AVWeapon_Bow
local ABP_WeaponBowPlaceholder_C = {}


