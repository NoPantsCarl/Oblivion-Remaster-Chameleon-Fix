---@meta

---@class UAST_CharacterLocomotionSneakLanding_C : UVState
---@field UberGraphFrame FPointerToUberGraphFrame
---@field PairedPawn AVPairedPawn
local UAST_CharacterLocomotionSneakLanding_C = {}

---@param DeltaTime float
function UAST_CharacterLocomotionSneakLanding_C:OnStateUpdate(DeltaTime) end
function UAST_CharacterLocomotionSneakLanding_C:PostInit() end
function UAST_CharacterLocomotionSneakLanding_C:OnEntered() end
---@param EntryPoint int32
function UAST_CharacterLocomotionSneakLanding_C:ExecuteUbergraph_AST_CharacterLocomotionSneakLanding(EntryPoint) end


