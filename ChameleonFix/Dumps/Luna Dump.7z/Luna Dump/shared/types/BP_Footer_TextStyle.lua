---@meta

---@class UBP_Footer_TextStyle_C : UCommonTextStyle
local UBP_Footer_TextStyle_C = {}


