---@meta

---@class UNQF_CannotSwim_C : UNavigationQueryFilter
local UNQF_CannotSwim_C = {}


