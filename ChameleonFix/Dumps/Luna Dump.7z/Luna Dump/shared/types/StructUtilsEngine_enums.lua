---@enum EStructUtilsResult
local EStructUtilsResult = {
    Valid = 0,
    NotValid = 1,
    EStructUtilsResult_MAX = 2,
}

