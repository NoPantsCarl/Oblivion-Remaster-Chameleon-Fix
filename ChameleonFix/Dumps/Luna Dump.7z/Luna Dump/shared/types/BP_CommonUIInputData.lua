---@meta

---@class UBP_CommonUIInputData_C : UCommonUIInputData
local UBP_CommonUIInputData_C = {}


