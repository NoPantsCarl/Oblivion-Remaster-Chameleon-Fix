---@meta

---@class UASM_Sneaking_Bow_C : UVStateMachine
---@field UberGraphFrame FPointerToUberGraphFrame
local UASM_Sneaking_Bow_C = {}

---@param EntryPoint int32
function UASM_Sneaking_Bow_C:ExecuteUbergraph_ASM_Sneaking_Bow(EntryPoint) end


