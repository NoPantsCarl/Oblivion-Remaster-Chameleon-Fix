---@meta

---@class UBP_UIButtonStyle_Footer_C : UCommonButtonStyle
local UBP_UIButtonStyle_Footer_C = {}


