---@meta

---@class FFluidForceSocketInfo
---@field SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5 TMap<FName, FName>
local FFluidForceSocketInfo = {}



