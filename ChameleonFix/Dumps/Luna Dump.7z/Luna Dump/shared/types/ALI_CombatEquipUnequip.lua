---@meta

---@class IALI_CombatEquipUnequip_C : IAnimLayerInterface
local IALI_CombatEquipUnequip_C = {}

---@param EquipUnequipLayer FPoseLink
function IALI_CombatEquipUnequip_C:EquipUnequipLayer(EquipUnequipLayer) end


