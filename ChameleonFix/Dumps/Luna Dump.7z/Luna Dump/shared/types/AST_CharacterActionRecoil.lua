---@meta

---@class UAST_CharacterActionRecoil_C : UVAltarActionState
---@field UberGraphFrame FPointerToUberGraphFrame
local UAST_CharacterActionRecoil_C = {}

---@param OutGameplayTag FGameplayTag
function UAST_CharacterActionRecoil_C:GetAnimTagsOverride(OutGameplayTag) end
function UAST_CharacterActionRecoil_C:OnEnded_C3FD5D7347D11FF7D1382398F7769C00() end
function UAST_CharacterActionRecoil_C:OnEntered() end
function UAST_CharacterActionRecoil_C:OnExited() end
---@param EntryPoint int32
function UAST_CharacterActionRecoil_C:ExecuteUbergraph_AST_CharacterActionRecoil(EntryPoint) end


