---@meta

---@class UAST_OnHorseIdle_C : UAST_CameraBase_C
local UAST_OnHorseIdle_C = {}


