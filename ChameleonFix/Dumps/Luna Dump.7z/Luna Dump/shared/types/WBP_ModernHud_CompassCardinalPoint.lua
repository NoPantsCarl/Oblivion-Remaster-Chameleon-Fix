---@meta

---@class UWBP_ModernHud_CompassCardinalPoint_C : UCommonUserWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field FaceText UWBP_AltarTextBlock_C
---@field Font FSlateFontInfo
---@field Text FText
local UWBP_ModernHud_CompassCardinalPoint_C = {}

---@param IsDesignTime boolean
function UWBP_ModernHud_CompassCardinalPoint_C:PreConstruct(IsDesignTime) end
---@param EntryPoint int32
function UWBP_ModernHud_CompassCardinalPoint_C:ExecuteUbergraph_WBP_ModernHud_CompassCardinalPoint(EntryPoint) end


