---@meta

---@class ABP_Ammo_Generic_Dropped_C : AVDroppedAmmo
---@field NewVar ABP_TargetActor_C
local ABP_Ammo_Generic_Dropped_C = {}

function ABP_Ammo_Generic_Dropped_C:UserConstructionScript() end


