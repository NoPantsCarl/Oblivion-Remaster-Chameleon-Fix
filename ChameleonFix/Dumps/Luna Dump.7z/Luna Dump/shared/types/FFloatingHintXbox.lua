---@meta

---@class FFFloatingHintXbox
---@field ActionName_6_53680FB543A3A59B5BE2FFA499E72922 FText
---@field ControllerButton_9_12ABA20145BE9588E3696588DFD51771 ELegacyXboxFloatingHintButton
local FFFloatingHintXbox = {}



