---@meta

---@class UBP_WalkCameraShake_Horse_C : ULegacyCameraShake
local UBP_WalkCameraShake_Horse_C = {}


