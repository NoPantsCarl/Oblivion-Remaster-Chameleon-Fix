---@meta

---@class ABP_LowerShirt05_C : ABP_Generic_FoldableClothes_C
local ABP_LowerShirt05_C = {}


