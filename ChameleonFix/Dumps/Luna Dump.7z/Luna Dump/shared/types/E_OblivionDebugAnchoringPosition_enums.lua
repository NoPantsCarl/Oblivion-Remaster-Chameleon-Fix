---@enum E_OblivionDebugAnchoringPosition
local E_OblivionDebugAnchoringPosition = {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    NewEnumerator3 = 3,
    E_MAX = 4,
}

