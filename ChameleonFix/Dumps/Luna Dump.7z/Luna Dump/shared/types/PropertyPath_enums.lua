---@enum EPropertyPathTestEnum
local EPropertyPathTestEnum = {
    One = 0,
    Two = 1,
    Three = 2,
    Four = 3,
    EPropertyPathTestEnum_MAX = 4,
}

