---@meta

---@class UBP_UIButtonStyle_HUDInputAction_C : UCommonButtonStyle
local UBP_UIButtonStyle_HUDInputAction_C = {}


