---@meta

---@class UCOND_IsOnGround_C : UCOND_Parent_C
local UCOND_IsOnGround_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsOnGround_C:CheckCondition(CurrentState) end


