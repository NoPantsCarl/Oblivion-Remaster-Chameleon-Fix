---@meta

---@class UWBP_ModernMenu_Magic_FilterIcon_Wrapper_C : UVAltarWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field filterIcon UWBP_ModernMenu_Magic_FilterIcon_C
local UWBP_ModernMenu_Magic_FilterIcon_Wrapper_C = {}

function UWBP_ModernMenu_Magic_FilterIcon_Wrapper_C:Construct() end
function UWBP_ModernMenu_Magic_FilterIcon_Wrapper_C:OnFocus() end
---@param EntryPoint int32
function UWBP_ModernMenu_Magic_FilterIcon_Wrapper_C:ExecuteUbergraph_WBP_ModernMenu_Magic_FilterIcon_Wrapper(EntryPoint) end


