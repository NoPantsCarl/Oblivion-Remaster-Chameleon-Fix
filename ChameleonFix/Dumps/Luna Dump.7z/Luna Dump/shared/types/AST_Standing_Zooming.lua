---@meta

---@class UAST_Standing_Zooming_C : UAST_CameraBase_C
local UAST_Standing_Zooming_C = {}


