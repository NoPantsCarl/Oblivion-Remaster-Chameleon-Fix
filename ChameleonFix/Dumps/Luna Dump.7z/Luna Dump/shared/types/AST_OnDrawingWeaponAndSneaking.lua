---@meta

---@class UAST_OnDrawingWeaponAndSneaking_C : UAST_CameraBase_C
local UAST_OnDrawingWeaponAndSneaking_C = {}


