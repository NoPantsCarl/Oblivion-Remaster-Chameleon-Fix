---@meta

---@class IALI_CombatAttacking_C : IAnimLayerInterface
local IALI_CombatAttacking_C = {}

---@param InPose FPoseLink
---@param AttackingLayer FPoseLink
function IALI_CombatAttacking_C:AttackingLayer(InPose, AttackingLayer) end


