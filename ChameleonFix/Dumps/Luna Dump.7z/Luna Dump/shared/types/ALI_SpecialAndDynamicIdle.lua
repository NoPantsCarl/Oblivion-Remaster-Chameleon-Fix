---@meta

---@class IALI_SpecialAndDynamicIdle_C : IAnimLayerInterface
local IALI_SpecialAndDynamicIdle_C = {}

---@param InPose FPoseLink
---@param SpecialAndDynamicIdleLayer FPoseLink
function IALI_SpecialAndDynamicIdle_C:SpecialAndDynamicIdleLayer(InPose, SpecialAndDynamicIdleLayer) end


