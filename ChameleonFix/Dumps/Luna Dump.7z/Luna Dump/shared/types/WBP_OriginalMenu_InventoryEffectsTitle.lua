---@meta

---@class UWBP_OriginalMenu_InventoryEffectsTitle_C : UUserWidget
local UWBP_OriginalMenu_InventoryEffectsTitle_C = {}


