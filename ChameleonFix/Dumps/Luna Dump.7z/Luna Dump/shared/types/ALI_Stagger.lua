---@meta

---@class IALI_Stagger_C : IAnimLayerInterface
local IALI_Stagger_C = {}

---@param InPose FPoseLink
---@param StaggerLayer FPoseLink
function IALI_Stagger_C:StaggerLayer(InPose, StaggerLayer) end


