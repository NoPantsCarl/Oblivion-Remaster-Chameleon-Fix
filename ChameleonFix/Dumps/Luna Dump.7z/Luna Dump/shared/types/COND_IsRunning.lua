---@meta

---@class UCOND_IsRunning_C : UCOND_Parent_C
local UCOND_IsRunning_C = {}

---@param CurrentState UVStateBase
---@return boolean
function UCOND_IsRunning_C:CheckCondition(CurrentState) end


