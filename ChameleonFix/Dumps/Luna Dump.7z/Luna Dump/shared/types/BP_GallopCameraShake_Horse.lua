---@meta

---@class UBP_GallopCameraShake_Horse_C : ULegacyCameraShake
local UBP_GallopCameraShake_Horse_C = {}


