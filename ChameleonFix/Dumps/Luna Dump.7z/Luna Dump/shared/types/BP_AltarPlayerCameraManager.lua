---@meta

---@class ABP_AltarPlayerCameraManager_C : AVAltarPlayerCameraManager
local ABP_AltarPlayerCameraManager_C = {}

---@param HasCorrectTags boolean
function ABP_AltarPlayerCameraManager_C:HasTagsToEnterVanityCam(HasCorrectTags) end
---@param DeltaTime double
function ABP_AltarPlayerCameraManager_C:UpdateForVanityCamera(DeltaTime) end


