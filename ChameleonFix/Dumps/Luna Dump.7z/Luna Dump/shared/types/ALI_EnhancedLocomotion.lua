---@meta

---@class IALI_EnhancedLocomotion_C : IAnimLayerInterface
local IALI_EnhancedLocomotion_C = {}

---@param InPose FPoseLink
---@param EnhancedLocomotionLayer FPoseLink
function IALI_EnhancedLocomotion_C:EnhancedLocomotionLayer(InPose, EnhancedLocomotionLayer) end


