---@meta

---@class IBPI_Day_Night_C : IInterface
local IBPI_Day_Night_C = {}

function IBPI_Day_Night_C:Set_Night() end
function IBPI_Day_Night_C:Set_Day() end


